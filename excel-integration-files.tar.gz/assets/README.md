The Office Add-in requires PNG icons. 
Please convert the SVG files to PNG using:
1. An online converter like https://cloudconvert.com/svg-to-png
2. Command line tools like ImageMagick: convert icon-32.svg icon-32.png
3. Or use the icon-generator.html file in this directory
