# Excel Integration Setup - Quick Start

## ✅ Completed Setup

1. **SSL Certificates**: Generated in `/certs` directory
2. **Excel Add-in Server**: Ready on port 3000
3. **WebSocket Bridge**: Configured for Excel-Electron communication

## 🚀 To Connect Excel to Wendigo:

### Step 1: Start Wendigo
```bash
npm run dev
```
Wait for "Excel add-in server running at https://localhost:3000"

### Step 2: Side-load in Excel

**On Mac:**
1. Open Excel
2. Insert → Add-ins → My Add-ins
3. Click "Manage My Add-ins" → "Upload My Add-in"
4. Browse to `/workspace/wendigo/manifest.xml`
5. Click Upload

**On Windows:**
Same process, or use: `npm run sideload-excel`

### Step 3: Use Wendigo in Excel
1. Look for "Wendigo" button in Home tab
2. Click to open the AI assistant panel
3. The panel shows connection status

## 🔧 Troubleshooting

If Excel shows certificate warnings:
- The self-signed certificates are in `/certs`
- Excel may show a warning - click "Continue" or "Trust"

If connection fails:
- Ensure Wendigo app is running (`npm run dev`)
- Check port 3000 is free
- Look at console for errors

## 📝 What's Working Now:

- ✅ Express server serves Excel add-in files
- ✅ WebSocket connection for real-time communication
- ✅ Excel can read/write cells through Wendigo
- ✅ AI chat interface in Excel taskpane
- ✅ Context awareness (selected cells, workbook info)

The Excel integration is ready to use!